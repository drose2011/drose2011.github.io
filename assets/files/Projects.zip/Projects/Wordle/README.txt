To run this solver, simply make wordle.c, and then run the wordle executable that is made. 

It will prompt you with the word it guesses, and you must reply with the accuracy for each letter (0 = grey = not in target word, 1 = yellow = in target word in a diff position, 2 = green = correct position and letter).

This project was a personal project I worked on in 2021.
