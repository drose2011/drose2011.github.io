To run this solver, simply make flow.c, and then run the flow executable that is made. It has about 25 built in boards that can be chosen from by choosing the starting index. 

This project was a personal project I worked on in 2022.
